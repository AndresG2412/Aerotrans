export default function Dashboard() {
    return(
        <>
            <p>Listando los pedidos para admins</p>
        </>
    );
}